import { useState } from "react";
import { db } from "../firebase";
import { collection, addDoc } from "firebase/firestore";

export default function CreateRoom({ user, onBack }) {
  const [roomData, setRoomData] = useState({
    name: "",
    description: "",
    previewURL: ""
  });

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!roomData.name) return alert("Room name is required!");
    try {
      await addDoc(collection(db, "studyRooms"), {
        ...roomData,
        createdBy: user.uid // store the creator
      });
      alert("Room created successfully!");
      onBack(); // go back to StudyRoomList
    } catch (err) {
      alert("Error creating room: " + err.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <form
        className="bg-white p-6 rounded-xl shadow-md w-full max-w-md space-y-4"
        onSubmit={handleCreate}
      >
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">Create Study Room</h2>
          <button type="button" onClick={onBack} className="text-red-600 text-xl font-bold">&times;</button>
        </div>

        <input
          type="text"
          placeholder="Room Name"
          value={roomData.name}
          onChange={(e) => setRoomData({ ...roomData, name: e.target.value })}
          className="w-full p-2 border rounded"
        />
        <textarea
          placeholder="Description"
          value={roomData.description}
          onChange={(e) => setRoomData({ ...roomData, description: e.target.value })}
          className="w-full p-2 border rounded"
        />
        <input
          type="text"
          placeholder="Preview Video URL (optional)"
          value={roomData.previewURL}
          onChange={(e) => setRoomData({ ...roomData, previewURL: e.target.value })}
          className="w-full p-2 border rounded"
        />

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition"
        >
          Create Room
        </button>
      </form>
    </div>
  );
}
