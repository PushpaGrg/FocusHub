// src/App.jsx
import { useState, useEffect } from "react";
import { auth, db } from "./firebase";
import { signOut, updateEmail } from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";

import Home from "./pages/Home";
import Login from "./pages/Login";
import StudyRoomList from "./pages/StudyRoomList";
import RoomMessages from "./pages/RoomMessages";
import EditProfile from "./pages/EditProfile";

export default function App() {
  const [user, setUser] = useState(undefined);
  const [profile, setProfile] = useState(null); // stores profile data including photoBase64
  const [isGuest, setIsGuest] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [editingProfile, setEditingProfile] = useState(false);

  // Listen for auth changes and fetch profile
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (u) => {
      setUser(u);
      if (u) {
        const docRef = doc(db, "users", u.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setProfile(docSnap.data());
        } else {
          setProfile({
            username: u.email.split("@")[0],
            fullName: "",
            fieldOfStudy: "",
            email: u.email,
            photoBase64: null,
          });
        }
      } else {
        setProfile(null);
      }
      setShowLogin(false);
    });
    return () => unsubscribe();
  }, []);

  // Save profile changes
  const handleProfileUpdate = async (updatedData) => {
    try {
      const docRef = doc(db, "users", user.uid);
      await setDoc(docRef, updatedData, { merge: true });

      // Update email if changed
      if (updatedData.email && updatedData.email !== user.email) {
        await updateEmail(user, updatedData.email);
      }

      setProfile(updatedData); // immediately update local state
      setEditingProfile(false); // go back to StudyRoomList
    } catch (err) {
      alert("Error updating profile: " + err.message);
    }
  };

  const handleSelectRoom = (room) => {
    if (!user && !isGuest) {
      alert("Please login or sign up to enter a study room!");
      return;
    }
    setSelectedRoom(room);
  };

  const handleLogout = async () => {
    await signOut(auth);
    setUser(null);
    setProfile(null);
    setSelectedRoom(null);
  };

  // Loading
  if (user === undefined)
    return (
      <div className="min-h-screen flex items-center justify-center">
        Loading...
      </div>
    );

  if (showLogin) return <Login onLogin={() => setShowLogin(false)} />;
  if (!user && !isGuest)
    return <Home onGuest={() => setIsGuest(true)} onLoginClick={() => setShowLogin(true)} />;

  if (editingProfile)
    return (
      <EditProfile
        user={profile}
        onSave={handleProfileUpdate}
        onCancel={() => setEditingProfile(false)}
      />
    );

  if (selectedRoom)
    return <RoomMessages room={selectedRoom} user={profile} onBack={() => setSelectedRoom(null)} />;

  return (
    <StudyRoomList
      user={profile} // pass updated profile including base64 photo
      onSelectRoom={handleSelectRoom}
      onLogout={handleLogout}
      onEditProfile={() => setEditingProfile(true)}
    />
  );
}
